"use strict";(()=>{var w={off:0,error:1,warn:2,info:3,debug:4},L="error";function G(e){L=e}var s={debug:(...e)=>{w[L]>=w.debug&&console.log("Tolerance:",...e)},info:(...e)=>{w[L]>=w.info&&console.log("Tolerance:",...e)},warn:(...e)=>{w[L]>=w.warn&&console.warn("Tolerance:",...e)},error:(...e)=>{w[L]>=w.error&&console.error("Tolerance:",...e)}};var O={economic:["collapse","crash","recession","depression","hyperinflation","bubble burst","bubble bursting","can't afford","priced out","housing crisis","wage stagnation","layoffs everywhere","job market dead","economy tanking","market crash","financial ruin","going bankrupt","poverty"],political:["democracy dying","democracy dead","end times","country is doomed","no hope left","nothing will change","both sides same","rigged system","point of no return","too far gone","beyond saving","irreversible damage","no way back","failed state"],existential:["humanity doomed","no future","too late","giving up","why bother","what's the point","learned helplessness","nothing matters","inevitable decline","all downhill","beyond repair","hopeless","despair","nihilism"]},_={hidden_forces:["they don't want you to know","wake up","open your eyes","hidden agenda","puppet masters","pulling strings","controlled opposition","deep state","powers that be","shadow government","secret cabal","ruling class"],coordinated:["psyop","propaganda","manufactured","astroturfing","narrative control","media manipulation","cover up","suppressed","silenced","censored truth","coordinated attack","disinformation campaign","controlled narrative"],revelation:["exposed","leaked","whistleblower","secret documents","finally revealed","proof they","caught red handed","smoking gun","hidden truth","real story"]},z={alienation:["forever alone","no one understands","outsider","don't belong","black sheep","outcast","invisible","nobody cares","all alone","isolated","disconnected","alienated"],grievance:["always blamed","under attack","discriminated against","demonized","scapegoat","targeted","hated for being","persecuted","vilified","marginalized"],hopelessness:["will never","impossible to","gave up on","not for people like me","rigged against","can't win","system designed to fail","born to lose","no chance","destined to fail"]};var He=[{id:"doom",name:"Doom / Hopelessness",description:"Content promoting despair, learned helplessness, economic collapse fears, or nihilism. Often frames situations as irreversible and action as pointless.",keywords:[...O.economic,...O.political,...O.existential],isSystemTheme:!0,active:!0},{id:"conspiracy",name:"Conspiracy / Manipulation",description:`Content suggesting hidden forces control events, "they don't want you to know" framing, or coordinated cover-ups without evidence.`,keywords:[..._.hidden_forces,..._.coordinated,..._.revelation],isSystemTheme:!0,active:!0},{id:"identity",name:"Identity / Isolation",description:'Content promoting alienation, identity-based grievance, or "forever alone" narratives. Often frames social connection as impossible.',keywords:[...z.alienation,...z.grievance,...z.hopelessness],isSystemTheme:!0,active:!0}];function Y(){let e=[],t=document.querySelectorAll("#siteTable > .thing.link");for(let o of t){let n=he(o);n&&e.push(n)}return e}function he(e){try{let t=e.getAttribute("data-fullname");if(!t)return null;let o=t.replace("t3_",""),n=e.querySelector("a.title"),i=n?.textContent?.trim()||"";if(!i)return null;let c=(e.querySelector("a.subreddit")?.textContent||"").replace(/^r\//,""),m=e.querySelector("a.author")?.textContent||"[deleted]",b=e.querySelector(".score.unvoted"),g=b?.getAttribute("title")||b?.textContent||"",f=!g||g==="\u2022"||g==="\u2014"||!/\d/.test(g)?null:parseInt(g.replace(/[^0-9-]/g,""),10)||0,u=e.querySelector("a.comments"),v=u?.textContent||"0",r=parseInt(v.replace(/[^0-9]/g,""),10)||0,h=u?.getAttribute("href")||"",y=h.startsWith("http")?new URL(h).pathname:h,P=e.querySelector(".domain")?.textContent?.replace(/[()]/g,"").trim()||"",ue=fe(e,P),pe=e.querySelector(".linkflairlabel")?.textContent?.trim(),me=e.classList.contains("over18"),q=e.getAttribute("data-timestamp"),ge=q?parseInt(q,10)/1e3:Date.now()/1e3,S,D=e.querySelector("a.thumbnail img");if(D?.src&&!D.src.includes("data:")&&(S=D.src),!S){let A=e.querySelector("a.thumbnail");if(A){let F=A.style.backgroundImage?.match(/url\(["']?([^"')]+)["']?\)/);F?.[1]&&(S=F[1])}}if(!S){let H=e.querySelector("[data-url]")?.getAttribute("data-url");H&&(S=H)}let k=n?.getAttribute("href")||"",R=P.toLowerCase(),j;(R.includes("i.redd.it")||R.includes("imgur.com/")||k.match(/\.(jpg|jpeg|png|gif|webp)$/i))&&(j=k.startsWith("http")?k:`https://reddit.com${k}`);let W;return(R.includes("v.redd.it")||R.includes("gfycat")||R.includes("redgifs"))&&(W=k.startsWith("http")?k:`https://reddit.com${k}`),{id:o,platform:"reddit",text:i,title:i,subreddit:c,author:m,score:f,numComments:r,upvoteRatio:void 0,flair:pe,isNsfw:me,mediaType:ue,permalink:y,domain:P,createdUtc:ge,thumbnailUrl:S,imageUrl:j,videoUrl:W,element:e}}catch(t){return console.error("Failed to parse post element:",t),null}}function fe(e,t){if(e.classList.contains("self"))return"text";if((e.querySelector("a.title")?.getAttribute("href")||"").includes("/gallery/"))return"gallery";let i=e.querySelector("a.thumbnail");if(i){if(i.classList.contains("self"))return"text";if(i.classList.contains("image"))return"image";if(i.classList.contains("video"))return"video"}let a=t.toLowerCase();return a.includes("imgur")||a.includes("i.redd.it")||a.includes("gfycat")||a.endsWith(".jpg")||a.endsWith(".png")||a.endsWith(".gif")?"image":a.includes("youtube")||a.includes("youtu.be")||a.includes("v.redd.it")||a.includes("streamable")||a.includes("twitch")?"video":a.includes("reddit.com/gallery")?"gallery":"link"}function V(e){let{element:t,...o}=e;return o}function K(e,t,o,n=[]){let i=new Map(e.map(r=>[r.id,r])),a=[],l=document.querySelector("#siteTable");if(!l)return console.error("Tolerance: Could not find siteTable container"),a;let c=Array.from(l.querySelectorAll(".thing.link:not(.promoted)")).map(r=>{let h=r.getAttribute("data-fullname")?.replace("t3_","")||"?",y=t.get(h);return`${h.slice(0,6)}(${y?.apiScore??y?.heuristicScore??"?"})`}).slice(0,15);s.debug(`Reorder: Original DOM (${l.querySelectorAll(".thing.link:not(.promoted)").length} posts): ${c.join(", ")}`);let p=o.slice(0,15).map(r=>{let h=t.get(r);return`${r.slice(0,6)}(${h?.apiScore??h?.heuristicScore??"?"})`});s.debug(`Reorder: Requested order (${o.length} posts): ${p.join(", ")}`);let m=new Map;e.forEach((r,h)=>{m.set(r.id,h)});let b=document.createDocumentFragment(),g=[],d=Array.from(l.children);for(let r of d)(!r.classList.contains("thing")||!r.classList.contains("link")||r.classList.contains("promoted"))&&g.push(r);let f=0,u=0;for(let r of o){let h=i.get(r);if(!h){s.debug(`Reorder: Post ${r} not found in postMap`);continue}if(!h.element){s.debug(`Reorder: Post ${r} has no element`);continue}let y=t.get(r),$=m.get(r)??f,P=$!==f;a.push({timestamp:Date.now(),postId:r,score:y?.heuristicScore??50,bucket:y?.bucket??"medium",position:f,originalPosition:$,subreddit:h.subreddit,wasReordered:P,narrativeThemeId:y?.factors?.narrative?.themeId}),b.appendChild(h.element),u++,f++}s.debug(`Reorder: Appended ${u} posts to fragment, ${g.length} non-post elements`);for(let r of g)b.appendChild(r);for(;l.firstChild;)l.removeChild(l.firstChild);l.appendChild(b),n.length>0&&s.debug(`Reorder: ${n.length} high-engagement posts hidden (not in feed)`);let v=Array.from(l.querySelectorAll(".thing.link:not(.promoted)")).map(r=>{let h=r.getAttribute("data-fullname")?.replace("t3_","")||"?",y=t.get(h);return`${h.slice(0,6)}(${y?.apiScore??y?.heuristicScore??"?"})`}).slice(0,15);return s.debug(`Reorder: Final DOM (${l.querySelectorAll(".thing.link:not(.promoted)").length} visible posts): ${v.join(", ")}`),a}function B(e,t){return e.map((o,n)=>{let i=t.get(o.id);return{timestamp:Date.now(),postId:o.id,score:i?.heuristicScore??50,bucket:i?.bucket??"medium",position:n,originalPosition:n,subreddit:o.subreddit,wasReordered:!1,narrativeThemeId:i?.factors?.narrative?.themeId}})}var C=null,M=null;function J(e){C&&C.disconnect();let t=document.querySelector("#siteTable");if(!t){console.warn("Tolerance: #siteTable not found, cannot observe for new posts");return}C=new MutationObserver(o=>{let n=!1;for(let i of o){if(i.type==="childList"&&i.addedNodes.length>0){for(let a of i.addedNodes)if(a instanceof HTMLElement&&a.classList.contains("thing")&&a.classList.contains("link")){n=!0;break}}if(n)break}n&&(M!==null&&clearTimeout(M),M=window.setTimeout(()=>{M=null,e()},100))}),C.observe(t,{childList:!0,subtree:!1}),s.debug(" Observer set up for infinite scroll")}function Q(e){new MutationObserver(o=>{for(let n of o)if(n.type==="childList"){for(let i of n.addedNodes)if(i instanceof HTMLElement&&i.classList.contains("NERPageMarker")){setTimeout(e,200);return}}}).observe(document.body,{childList:!0,subtree:!0})}var X="tolerance-reminder-card",Z=["Resume Draft \u2192","Back to writing? \u2192","Your draft awaits \u2192","Pick up where you left off \u2192","The words won't write themselves \u2192"],ee=["Reach out to someone","Send one message today","Future you will thank you","One connection at a time","Plant a seed today"],be=["Open Project \u2192","Ship something \u2192","Back to the code \u2192","Build something cool \u2192"],ye=["Your Focus Today","Meanwhile, in reality...","A gentle nudge","Quick check-in","Your actual priorities"];function E(e){return e[Math.floor(Math.random()*e.length)]}function N(e){if(e<60)return`${e} min`;let t=Math.floor(e/60),o=e%60;return o===0?`${t}h`:`${t}h ${o}m`}function ve(e){let t=document.createElement("div");t.id=X,t.className="thing tolerance-card";let o="";if(e.state.mode==="baseline"){let l=(Date.now()-e.state.baselineStartDate)/(1e3*60*60*24);o=` (baseline: ${Math.max(0,e.state.baselineDurationDays-l).toFixed(0)} days)`}let n=e.productivity!==null,i=n?E(ye):"Tolerance";return t.innerHTML=`
    <style>
      .tolerance-card {
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        border: 1px solid #2a2a4a;
        border-radius: 8px;
        padding: 16px 20px;
        margin: 10px 0;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        color: #e0e0e0;
      }
      .tolerance-card-header {
        font-size: 14px;
        font-weight: 600;
        color: #a0a0c0;
        margin-bottom: 12px;
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .tolerance-card-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 8px 0;
        border-bottom: 1px solid #2a2a4a;
      }
      .tolerance-card-row:last-of-type {
        border-bottom: none;
      }
      .tolerance-card-label {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 14px;
      }
      .tolerance-card-value {
        font-size: 14px;
        font-weight: 500;
        color: #b0b0d0;
      }
      .tolerance-card-link {
        color: #7b8cde;
        text-decoration: none;
        font-size: 13px;
        padding: 4px 10px;
        background: rgba(123, 140, 222, 0.1);
        border-radius: 4px;
        transition: background 0.2s;
      }
      .tolerance-card-link:hover {
        background: rgba(123, 140, 222, 0.2);
        text-decoration: none;
      }
      .tolerance-card-divider {
        height: 1px;
        background: #2a2a4a;
        margin: 12px 0;
      }
      .tolerance-card-footer {
        font-size: 12px;
        color: #707090;
      }
      .tolerance-card-reminder {
        font-size: 13px;
        color: #a0a0c0;
        font-style: italic;
      }
      .tolerance-card-actions {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        gap: 6px;
      }
      .tolerance-msg-icons {
        display: flex;
        gap: 8px;
      }
      .tolerance-icon-link {
        color: #707090;
        transition: color 0.2s;
        display: flex;
        align-items: center;
      }
      .tolerance-icon-link:hover {
        color: #b0b0d0;
      }
    </style>
    <div class="tolerance-card-header">
      <span>\u{1F4CA}</span>
      <span>${i}</span>
    </div>
    ${n?we(e):xe(e)}
    <div class="tolerance-card-divider"></div>
    <div class="tolerance-card-footer">
      ${e.highEngagementToday} high-engagement posts seen today
      ${e.state.mode==="active"?" \xB7 Feed reordering: active":o}
    </div>
  `,t}function we(e){let t=e.productivity,o=e.settings,n="";n+=`
    <div class="tolerance-card-row">
      <div class="tolerance-card-label">
        <span>\u270D\uFE0F</span>
        <span>Writing</span>
        <span class="tolerance-card-value">${N(t.writing)}</span>
      </div>
      ${o.obsidianUrl?`<a href="${o.obsidianUrl}" class="tolerance-card-link">${E(Z)}</a>`:'<span class="tolerance-card-reminder">Set article in popup</span>'}
    </div>
  `,n+=`
    <div class="tolerance-card-row">
      <div class="tolerance-card-label">
        <span>\u{1F4BC}</span>
        <span>Job Search</span>
        <span class="tolerance-card-value">${N(t.jobSearch)}</span>
      </div>
      <div class="tolerance-card-actions">
        <span class="tolerance-card-reminder">${E(ee)}</span>
        <div class="tolerance-msg-icons">
          <a href="https://web.whatsapp.com/" target="_blank" title="WhatsApp" class="tolerance-icon-link">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
          </a>
          <a href="sgnl://open" title="Signal" class="tolerance-icon-link">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm0 3.6c4.635 0 8.4 3.765 8.4 8.4 0 4.635-3.765 8.4-8.4 8.4-1.5 0-2.906-.394-4.122-1.083l-.288-.166-2.988.783.798-2.916-.182-.298A8.347 8.347 0 013.6 12c0-4.635 3.765-8.4 8.4-8.4z"/></svg>
          </a>
          <a href="https://web.telegram.org/" target="_blank" title="Telegram" class="tolerance-icon-link">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/></svg>
          </a>
          <a href="https://www.linkedin.com/messaging/" target="_blank" title="LinkedIn" class="tolerance-icon-link">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
          </a>
        </div>
      </div>
    </div>
  `,n+=`
    <div class="tolerance-card-row">
      <div class="tolerance-card-label">
        <span>\u{1F4BB}</span>
        <span>Coding</span>
        <span class="tolerance-card-value">${N(t.coding)}</span>
      </div>
      ${o.codingProjectLink?`<a href="${o.codingProjectLink}" target="_blank" class="tolerance-card-link">${E(be)}</a>`:""}
    </div>
  `;let i=o.todoistUrl||"https://todoist.com/app/today";return n+=`
    <div class="tolerance-card-row">
      <div class="tolerance-card-label">
        <span>\u2705</span>
        <span>Tasks</span>
      </div>
      <a href="${i}" target="_blank" class="tolerance-card-link">Check Todoist \u2192</a>
    </div>
  `,n}function xe(e){let t=e.settings,o="";o+=`
    <div class="tolerance-card-row">
      <div class="tolerance-card-label">
        <span>\u270D\uFE0F</span>
        <span>Writing</span>
      </div>
      ${t.obsidianUrl?`<a href="${t.obsidianUrl}" class="tolerance-card-link">${E(Z)}</a>`:'<span class="tolerance-card-reminder">Set article in popup</span>'}
    </div>
  `,o+=`
    <div class="tolerance-card-row">
      <div class="tolerance-card-label">
        <span>\u{1F4BC}</span>
        <span>Job Search</span>
      </div>
      <div class="tolerance-card-actions">
        <span class="tolerance-card-reminder">${E(ee)}</span>
        <div class="tolerance-msg-icons">
          <a href="https://web.whatsapp.com/" target="_blank" title="WhatsApp" class="tolerance-icon-link">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
          </a>
          <a href="sgnl://open" title="Signal" class="tolerance-icon-link">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm0 3.6c4.635 0 8.4 3.765 8.4 8.4 0 4.635-3.765 8.4-8.4 8.4-1.5 0-2.906-.394-4.122-1.083l-.288-.166-2.988.783.798-2.916-.182-.298A8.347 8.347 0 013.6 12c0-4.635 3.765-8.4 8.4-8.4z"/></svg>
          </a>
          <a href="https://web.telegram.org/" target="_blank" title="Telegram" class="tolerance-icon-link">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/></svg>
          </a>
          <a href="https://www.linkedin.com/messaging/" target="_blank" title="LinkedIn" class="tolerance-icon-link">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
          </a>
        </div>
      </div>
    </div>
  `;let n=t.todoistUrl||"https://todoist.com/app/today";return o+=`
    <div class="tolerance-card-row">
      <div class="tolerance-card-label">
        <span>\u2705</span>
        <span>Tasks</span>
      </div>
      <a href="${n}" target="_blank" class="tolerance-card-link">Check Todoist \u2192</a>
    </div>
  `,o}function te(e){let t=document.getElementById(X);if(t){let p=t.dataset.hiddenPostId;if(p){let m=document.querySelector(`[data-fullname="${p}"]`);m&&(m.style.display="")}t.remove()}let o=document.querySelector("#siteTable");if(!o){console.warn("Tolerance: Could not find #siteTable for card injection");return}let n=o.querySelectorAll(".thing.link:not(.promoted)"),i=ve(e),a=2,l=Math.min(5,n.length-1),c=a+Math.floor(Math.random()*(l-a+1));if(n.length>c){let p=n[c];p.parentNode?.insertBefore(i,p),p.style.display="none",i.dataset.hiddenPostId=p.dataset.fullname||""}else n.length>0&&o.appendChild(i);s.debug(` Reminder card injected at position ${c+1}`)}var oe=new Set,ke=3e4,ne=null;function U(){chrome.runtime.sendMessage({type:"SOCIAL_MEDIA_HEARTBEAT"},()=>{chrome.runtime.lastError})}function Se(){ne||(U(),ne=setInterval(U,ke),document.addEventListener("visibilitychange",()=>{document.visibilityState==="visible"&&U()}),s.debug(" Heartbeat tracking started"))}var ie=!1;function le(){if(ie)return;ie=!0;let e=document.createElement("style");e.textContent=`
    /* Blur/fade effect on posts during loading */
    #siteTable.tolerance-loading .thing {
      filter: blur(2px);
      opacity: 0.5;
      transition: filter 0.2s ease, opacity 0.2s ease;
      pointer-events: none;
    }

    #siteTable .thing {
      transition: filter 0.2s ease, opacity 0.2s ease;
    }

    /* Loading spinner overlay */
    .tolerance-loader {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      z-index: 9999;
      display: none;
      flex-direction: column;
      align-items: center;
      gap: 12px;
      background: rgba(30, 30, 30, 0.9);
      padding: 20px 28px;
      border-radius: 12px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
    }

    .tolerance-loader.visible {
      display: flex;
    }

    .tolerance-loader-spinner {
      width: 32px;
      height: 32px;
      border: 3px solid rgba(125, 206, 160, 0.3);
      border-top-color: #7dcea0;
      border-radius: 50%;
      animation: tolerance-spin 0.8s linear infinite;
    }

    .tolerance-loader-text {
      color: #e0e0e0;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 14px;
      font-weight: 500;
    }

    @keyframes tolerance-spin {
      to { transform: rotate(360deg); }
    }

    /* Score badges */
    .tolerance-score-badge {
      position: absolute !important;
      top: 4px !important;
      right: 4px !important;
      padding: 2px 8px !important;
      border-radius: 12px !important;
      font-size: 11px !important;
      font-weight: 600 !important;
      font-family: -apple-system, BlinkMacSystemFont, sans-serif !important;
      color: white !important;
      opacity: 0.85 !important;
      z-index: 9999 !important;
      pointer-events: auto !important;
      cursor: help !important;
      box-shadow: 0 1px 3px rgba(0,0,0,0.3) !important;
      display: block !important;
    }
    .tolerance-score-badge.high { background: #e74c3c !important; }
    .tolerance-score-badge.medium { background: #f39c12 !important; }
    .tolerance-score-badge.low { background: #27ae60 !important; }

    /* Badge tooltip */
    .tolerance-score-badge .tolerance-tooltip {
      visibility: hidden;
      opacity: 0;
      position: absolute;
      bottom: 100%;
      right: 0;
      margin-bottom: 8px;
      padding: 8px 12px;
      background: rgba(20, 20, 20, 0.95);
      color: #e0e0e0;
      border-radius: 8px;
      font-size: 12px;
      font-weight: 400;
      white-space: nowrap;
      box-shadow: 0 2px 8px rgba(0,0,0,0.4);
      transition: opacity 0.15s ease, visibility 0.15s ease;
      z-index: 10000;
      pointer-events: none;
    }
    .tolerance-score-badge:hover .tolerance-tooltip {
      visibility: visible;
      opacity: 1;
    }
    .tolerance-tooltip-reason {
      margin-bottom: 4px;
      font-style: italic;
      max-width: 250px;
      white-space: normal;
    }
    .tolerance-tooltip-positions {
      font-size: 11px;
      color: #aaa;
    }
    .tolerance-tooltip-positions.moved-up { color: #7dcea0; }
    .tolerance-tooltip-positions.moved-down { color: #e67e73; }
  `,document.head.appendChild(e)}function Ee(e,t){let o=e.element;if(!o){s.debug(` Badge injection failed - no element for post ${e.id}`);return}if(o.querySelector(".tolerance-score-badge")){s.debug(` Badge already exists for post ${e.id}`);return}getComputedStyle(o).position==="static"&&(o.style.position="relative");let n=document.createElement("div");n.className=`tolerance-score-badge ${t.bucket}`,n.textContent=String(Math.round(t.score));let i=document.createElement("div");if(i.className="tolerance-tooltip",t.reason){let c=document.createElement("div");c.className="tolerance-tooltip-reason",c.textContent=`"${t.reason}"`,i.appendChild(c)}let a=document.createElement("div"),l=t.originalPosition-t.newPosition;l>0?(a.className="tolerance-tooltip-positions moved-up",a.textContent=`Position: ${t.originalPosition+1} \u2192 ${t.newPosition+1} (\u2191${l})`):l<0?(a.className="tolerance-tooltip-positions moved-down",a.textContent=`Position: ${t.originalPosition+1} \u2192 ${t.newPosition+1} (\u2193${Math.abs(l)})`):(a.className="tolerance-tooltip-positions",a.textContent=`Position: ${t.newPosition+1} (unchanged)`),i.appendChild(a),n.appendChild(i),o.appendChild(n),s.debug(` Badge injected for post ${e.id}, score=${t.score}, bucket=${t.bucket}`)}function Te(){let e=document.querySelector(".tolerance-loader");return e||(e=document.createElement("div"),e.className="tolerance-loader",e.innerHTML=`
    <div class="tolerance-loader-spinner"></div>
    <div class="tolerance-loader-text">Analyzing posts...</div>
  `,document.body.appendChild(e),e)}function Pe(){le();let e=document.querySelector("#siteTable");e&&e.classList.add("tolerance-loading"),Te().classList.add("visible")}function Re(){let e=document.querySelector("#siteTable");e&&e.classList.remove("tolerance-loading");let t=document.querySelector(".tolerance-loader");t&&t.classList.remove("visible")}var x=null,I=null;function ae(){return document.querySelector("#siteTable")!==null}function Le(){return window.location.pathname.includes("/comments/")}async function se(){if(s.debug(" Content script loaded on",window.location.href),!ae()){s.debug(" Not old Reddit interface, waiting for DOM or skipping..."),setTimeout(()=>{ae()?re():s.debug(" New Reddit detected, extension inactive (old Reddit only for now)")},1e3);return}await re()}async function re(){let e=await T({type:"GET_STATE"});if(e&&"state"in e){if(x=e.state,I=e.settings,I.logLevel&&G(I.logLevel),I.platforms?.reddit===!1){s.debug(" Reddit platform disabled in settings, extension inactive");return}if(s.debug(" Mode =",x.mode),x.mode==="baseline"){let o=Ce();s.debug(` Baseline mode - ${o.toFixed(1)} days remaining`)}}let t=await T({type:"ENSURE_SESSION"});s.debug(" Session result:",t),Se(),await de(),J(ce),Q(ce)}function Ce(){if(!x)return 7;let t=(Date.now()-x.baselineStartDate)/(1e3*60*60*24);return Math.max(0,x.baselineDurationDays-t)}async function ce(){s.debug(" New posts detected"),await de()}async function de(){let e=performance.now(),t=Y(),o=performance.now(),n=t.filter(a=>!oe.has(a.id));if(n.length===0)return;let i=!Le();i&&Pe();try{s.debug(` Processing ${n.length} new posts (scrape: ${(o-e).toFixed(0)}ms)`);for(let d of n)oe.add(d.id);let a=n.map(V),l=performance.now(),c=await T({type:"SCORE_POSTS",posts:a}),p=performance.now();if(s.debug(` SCORE_POSTS took ${(p-l).toFixed(0)}ms`),!c||!("scores"in c)){console.error("Tolerance: Failed to get scores");return}let m=new Map;for(let d of c.scores)m.set(d.postId,d);let b=new Map(n.map(d=>[d.id,d]));le(),Ie(c.scores);let g;if(s.debug(` Current mode = ${x?.mode}`),x?.mode==="baseline")s.debug(" Baseline mode - skipping reorder"),g=B(n,m);else{let d=await T({type:"GET_SCHEDULER_ORDER",postIds:n.map(f=>f.id),scores:c.scores});if(d&&"orderedIds"in d){let f=d.orderedIds,u=d.hiddenIds||[];s.debug(` Scheduler returned order (first 10): ${f.slice(0,10).map(v=>{let r=m.get(v);return r?.apiScore??r?.heuristicScore??"?"}).join(", ")}`),u.length>0&&s.debug(` Hiding ${u.length} posts: ${u.slice(0,5).join(", ")}${u.length>5?"...":""}`),g=K(n,m,f,u),s.debug(` Reordered ${g.filter(v=>v.wasReordered).length} posts, hidden ${u.length}`)}else s.debug(" No order result from scheduler"),g=B(n,m)}for(let d of g){let f=b.get(d.postId),u=m.get(d.postId);if(f&&u){let v=u.apiScore??u.heuristicScore;u.apiReason?s.debug(` Post ${f.id} has apiReason: "${u.apiReason}"`):s.debug(` Post ${f.id} has NO apiReason, apiScore=${u.apiScore}`),Ee(f,{score:v,bucket:u.bucket,reason:u.apiReason,originalPosition:d.originalPosition,newPosition:d.position})}}await T({type:"LOG_IMPRESSIONS",impressions:g}),await Me()}finally{i&&Re()}}async function Me(){try{let e=await T({type:"GET_CARD_DATA"});if(e&&e.type==="CARD_DATA_RESULT"){if(!e.settings.productivityCardEnabled)return;let t={productivity:e.productivity,settings:e.settings,state:e.state,highEngagementToday:e.highEngagementToday};te(t)}}catch(e){console.error("Tolerance: Failed to inject productivity card:",e)}}function Ie(e){let t={high:0,medium:0,low:0};for(let o of e)t[o.bucket]++;s.debug(`Scores - High: ${t.high}, Medium: ${t.medium}, Low: ${t.low}`)}async function T(e){return new Promise(t=>{chrome.runtime.sendMessage(e,o=>{chrome.runtime.lastError?(console.error("Tolerance: Message error:",chrome.runtime.lastError),t(null)):t(o)})})}chrome.runtime.onMessage.addListener((e,t,o)=>{if(e.type==="FETCH_IMAGE_BASE64")return $e(e.url).then(n=>o({success:!0,base64:n})).catch(n=>o({success:!1,error:n.message})),!0});async function $e(e){let t=e;if(e.includes("preview.redd.it")){let o=e.match(/preview\.redd\.it\/([^?]+)/);o&&(t=`https://i.redd.it/${o[1]}`,s.debug(` Transformed URL from preview to i.redd.it: ${t}`))}return new Promise((o,n)=>{let i=new Image;i.crossOrigin="anonymous";let a=setTimeout(()=>{n(new Error("Image load timeout"))},1e4);i.onload=()=>{clearTimeout(a);try{let c=i.naturalWidth,p=i.naturalHeight;if(c>1024||p>1024){let d=1024/Math.max(c,p);c=Math.round(c*d),p=Math.round(p*d)}let m=document.createElement("canvas");m.width=c,m.height=p;let b=m.getContext("2d");if(!b){n(new Error("Could not get canvas context"));return}b.drawImage(i,0,0,c,p);let g=m.toDataURL("image/jpeg",.8);s.debug(` Image converted successfully: ${c}x${p}, ${g.length} chars`),o(g)}catch(l){n(new Error(`Canvas export failed: ${l}`))}},i.onerror=()=>{clearTimeout(a),n(new Error("Image load failed"))},i.src=t})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",se):se();})();
