"use strict";(()=>{var T={off:0,error:1,warn:2,info:3,debug:4},M="error";function te(e){M=e}var a={debug:(...e)=>{T[M]>=T.debug&&console.log("Tolerance:",...e)},info:(...e)=>{T[M]>=T.info&&console.log("Tolerance:",...e)},warn:(...e)=>{T[M]>=T.warn&&console.warn("Tolerance:",...e)},error:(...e)=>{T[M]>=T.error&&console.error("Tolerance:",...e)}};var Y={economic:["collapse","crash","recession","depression","hyperinflation","bubble burst","bubble bursting","can't afford","priced out","housing crisis","wage stagnation","layoffs everywhere","job market dead","economy tanking","market crash","financial ruin","going bankrupt","poverty"],political:["democracy dying","democracy dead","end times","country is doomed","no hope left","nothing will change","both sides same","rigged system","point of no return","too far gone","beyond saving","irreversible damage","no way back","failed state"],existential:["humanity doomed","no future","too late","giving up","why bother","what's the point","learned helplessness","nothing matters","inevitable decline","all downhill","beyond repair","hopeless","despair","nihilism"]},z={hidden_forces:["they don't want you to know","wake up","open your eyes","hidden agenda","puppet masters","pulling strings","controlled opposition","deep state","powers that be","shadow government","secret cabal","ruling class"],coordinated:["psyop","propaganda","manufactured","astroturfing","narrative control","media manipulation","cover up","suppressed","silenced","censored truth","coordinated attack","disinformation campaign","controlled narrative"],revelation:["exposed","leaked","whistleblower","secret documents","finally revealed","proof they","caught red handed","smoking gun","hidden truth","real story"]},F={alienation:["forever alone","no one understands","outsider","don't belong","black sheep","outcast","invisible","nobody cares","all alone","isolated","disconnected","alienated"],grievance:["always blamed","under attack","discriminated against","demonized","scapegoat","targeted","hated for being","persecuted","vilified","marginalized"],hopelessness:["will never","impossible to","gave up on","not for people like me","rigged against","can't win","system designed to fail","born to lose","no chance","destined to fail"]};var rt=[{id:"doom",name:"Doom / Hopelessness",description:"Content promoting despair, learned helplessness, economic collapse fears, or nihilism. Often frames situations as irreversible and action as pointless.",keywords:[...Y.economic,...Y.political,...Y.existential],isSystemTheme:!0,active:!0},{id:"conspiracy",name:"Conspiracy / Manipulation",description:`Content suggesting hidden forces control events, "they don't want you to know" framing, or coordinated cover-ups without evidence.`,keywords:[...z.hidden_forces,...z.coordinated,...z.revelation],isSystemTheme:!0,active:!0},{id:"identity",name:"Identity / Isolation",description:'Content promoting alienation, identity-based grievance, or "forever alone" narratives. Often frames social connection as impossible.',keywords:[...F.alienation,...F.grievance,...F.hopelessness],isSystemTheme:!0,active:!0}];function Q(){let e=[],t=document.querySelectorAll('article[data-testid="tweet"]');for(let o of t){let n=Pe(o);n&&e.push(n)}return e}function Pe(e){try{let o=e.querySelector('a[href*="/status/"]')?.getAttribute("href")||"",n=o.match(/\/status\/(\d+)/);if(!n)return null;let i=n[1],r=o,m=e.closest('[data-testid="cellInnerDiv"]')?.querySelector('[data-testid="socialContext"]'),l=m?.textContent?.includes("reposted")||!1,u=l?m?.textContent?.replace(" reposted","").trim():void 0,d=e.querySelector('[data-testid="User-Name"]'),b=d?.querySelector('a[href^="/"]')?.getAttribute("href")?.replace("/","")||"",h=d?.querySelector('[data-testid="icon-verified"]')!==null,s=e.querySelector('[data-testid="tweetText"]')?.textContent?.trim()||"",f=e.querySelector("time")?.getAttribute("datetime"),y=f?new Date(f).getTime()/1e3:Date.now()/1e3,S=H(e,"reply"),D=H(e,"retweet"),k=H(e,"like"),B=De(e),ve=H(e,"bookmark"),ee=He(e),Te=ee!==void 0,ot=e.querySelector('[data-testid="tweet"] > div > div > div > div > div > a[href*="/status/"]'),Ee=e.textContent?.includes("Replying to")||!1,Se=e.textContent?.match(/Replying to @(\w+)/)?.[1],xe=e.querySelector('[data-testid="Tweet-User-Avatar"]')?.closest("div")?.querySelector('[style*="border-left"]')!==null,Le=$e(e),{thumbnailUrl:Ie,imageUrl:ke,videoUrl:Me}=Ae(e),Ce=Oe(s),qe=_e(s),Re=Ue(e);return{id:i,platform:"twitter",author:b,text:s,score:k,numComments:S,mediaType:Le,permalink:r,createdUtc:y,thumbnailUrl:Ie,imageUrl:ke,videoUrl:Me,element:e,retweetCount:D,quoteCount:0,likeCount:k,viewCount:B,bookmarkCount:ve,isRetweet:l,isQuoteTweet:Te,isReply:Ee,isThread:xe,retweetedBy:u,quotedTweet:ee,replyToAuthor:Se,hashtags:Ce,mentions:qe,urls:Re,isVerified:h}}catch(t){return console.error("Tolerance: Failed to parse tweet element:",t),null}}function H(e,t){let o=e.querySelector(`[data-testid="${t}"]`);if(!o)return 0;let i=o.querySelector('span[data-testid="app-text-transition-container"]')?.textContent?.trim()||"0";return oe(i)}function De(e){let t=e.querySelector('a[href*="/analytics"]');if(!t)return;let n=(t.textContent?.trim()||"").match(/([\d,.]+[KMB]?)\s*views?/i);if(n)return oe(n[1])}function oe(e){if(!e||e==="")return 0;let o=e.toUpperCase().replace(/,/g,"").match(/([\d.]+)([KMB])?/);if(!o)return 0;let n=parseFloat(o[1]);switch(o[2]){case"K":return Math.round(n*1e3);case"M":return Math.round(n*1e6);case"B":return Math.round(n*1e9);default:return Math.round(n)}}function He(e){let t=e.querySelector('[data-testid="quoteTweet"]');if(!t){let l=e.querySelectorAll("span");for(let u of l)if(u.textContent?.trim()==="Quote"){let d=u.closest("div[class]");d&&(t=d.parentElement?.querySelector('[role="link"]')||null);break}}if(!t){let l=e.querySelectorAll('[data-testid="tweetText"]');l.length>=2&&(t=l[1].closest('[role="link"]'))}if(!t)return;let o="",n=t.querySelector('[data-testid="User-Name"] a[href^="/"]');if(n&&(o=n.getAttribute("href")?.replace("/","")||""),!o){let l=t.querySelector('[data-testid="User-Name"]');if(l){let u=l.querySelectorAll("span");for(let d of u){let g=d.textContent?.trim()||"";if(g.startsWith("@")){o=g.slice(1);break}}}}let i=t.querySelector('[data-testid="tweetText"]')?.textContent?.trim()||"",r,m=t.querySelector('[data-testid="tweetPhoto"] img');if(m?.src&&(r=m.src),!r){let l=t.querySelector("video");l?.poster&&(r=l.poster)}if(!r){let l=t.querySelector('img[src*="pbs.twimg.com/media"]');l?.src&&(r=l.src)}if(!(!o&&!i&&!r))return a.debug(` Parsed quote tweet - author=${o}, text="${i?.slice(0,30)}...", imageUrl=${r?.slice(0,50)}...`),{author:o,text:i,imageUrl:r}}function ne(e){let t=e.querySelector('[data-testid="quoteTweet"]');if(t)return t;let o=e.querySelectorAll("span");for(let i of o)if(i.textContent?.trim()==="Quote"){let r=i.closest("div[class]");if(r&&(t=r.parentElement?.querySelector('[role="link"]')||null,t))return t}let n=e.querySelectorAll('[data-testid="tweetText"]');return n.length>=2?n[1].closest('[role="link"]'):null}function $e(e){let t=ne(e),o=e.querySelectorAll('video, [data-testid="videoPlayer"]');for(let l of o)if(!t?.contains(l))return"video";let n=e.querySelectorAll('[data-testid="tweetPhoto"] img[src*="tweet_video_thumb"]');for(let l of n)if(!t?.contains(l))return"gif";let i=e.querySelectorAll('[data-testid="tweetPhoto"]'),r=0;for(let l of i)t?.contains(l)||r++;if(r>1)return"gallery";if(r===1)return"image";let m=e.querySelectorAll('[data-testid="card.wrapper"]');for(let l of m)if(!t?.contains(l))return"link";return"text"}function Ae(e){let t={},o=ne(e),n=e.querySelectorAll('[data-testid="tweetPhoto"] img');for(let r of n)if(!o?.contains(r)&&r.src){t.imageUrl=r.src,t.thumbnailUrl=r.src;break}let i=e.querySelectorAll("video");for(let r of i)if(!o?.contains(r)){t.videoUrl=r.src||r.querySelector("source")?.src,t.thumbnailUrl=r.poster||t.thumbnailUrl;break}return t}function Oe(e){return e.match(/#\w+/g)?.map(o=>o.slice(1))||[]}function _e(e){return e.match(/@\w+/g)?.map(o=>o.slice(1))||[]}function Ue(e){let t=[],o=e.querySelectorAll('[data-testid="card.wrapper"] a[href]');for(let i of o){let r=i.getAttribute("href");r&&!r.startsWith("/")&&!r.includes("twitter.com")&&t.push(r)}let n=e.querySelectorAll('[data-testid="tweetText"] a[href*="t.co"]');for(let i of n){let r=i.textContent?.trim();r&&r.startsWith("http")&&t.push(r)}return[...new Set(t)]}function re(e){let{element:t,...o}=e;return o}function ie(e,t,o){let n=new Map(e.map(p=>[p.id,p])),i=[],r=new Map;e.forEach((p,s)=>{r.set(p.id,s)});let m=new Map,l=new Map,u=new Map;for(let p of e){let s=p.element.closest('[data-testid="cellInnerDiv"]');if(s){m.set(p.id,s);let c=s.getBoundingClientRect().height;l.set(p.id,c);let y=(s.style.transform||"").match(/translateY\(([-\d.]+)px\)/),S=y?parseFloat(y[1]):0;u.set(p.id,S)}}let d=1/0;for(let p of u.values())p<d&&(d=p);d===1/0&&(d=0);let g=d,b=0,h=0;for(let p of o){let s=n.get(p);if(!s)continue;let c=m.get(p);if(!c)continue;let f=l.get(p)||0,y=t.get(p),S=r.get(p)??b,D=S!==b,k=u.get(p)||0,B=`translateY(${g}px)`;Math.abs(g-k)>1&&(c.style.transform=B,D&&(h++,a.debug(` Tweet ${p.slice(0,8)}... pos ${S}\u2192${b}, Y: ${k.toFixed(0)}\u2192${g.toFixed(0)}, height: ${f.toFixed(0)}`))),i.push({timestamp:Date.now(),postId:p,score:y?.heuristicScore??50,bucket:y?.bucket??"medium",position:b,originalPosition:S,subreddit:`@${s.author}`,wasReordered:D,narrativeThemeId:y?.factors?.narrative?.themeId}),g+=f,b++}return h>0&&a.debug(` Repositioned ${h} tweets with height-aware transforms`),i}function $(e,t){return e.map((o,n)=>{let i=t.get(o.id);return{timestamp:Date.now(),postId:o.id,score:i?.heuristicScore??50,bucket:i?.bucket??"medium",position:n,originalPosition:n,subreddit:`@${o.author}`,wasReordered:!1,narrativeThemeId:i?.factors?.narrative?.themeId}})}var A=null,W=null,Ne=500;function V(e){A&&A.disconnect();let t=()=>{let o=document.querySelector('[data-testid="primaryColumn"] section[role="region"]');if(!o){setTimeout(t,1e3);return}a.debug(" Setting up Twitter timeline observer"),A=new MutationObserver(n=>{let i=!1;for(let r of n){for(let m of r.addedNodes)if(m instanceof HTMLElement&&(m.querySelector?.('[data-testid="tweet"]')||m.matches?.('[data-testid="cellInnerDiv"]'))){i=!0;break}if(i)break}i&&(W&&clearTimeout(W),W=setTimeout(()=>{e()},Ne))}),A.observe(o,{childList:!0,subtree:!0})};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",t):t()}function se(e){let t=history.pushState,o=history.replaceState;history.pushState=function(...n){t.apply(this,n),e()},history.replaceState=function(...n){o.apply(this,n),e()},window.addEventListener("popstate",e)}var J=new Set,_=new Map,I=!1,q=!1,Be=12,X=!1,G=!1,Ye=3e4,E=null,ze=1e4,C=null,he=Date.now();function j(){if(!N()){E&&(clearInterval(E),E=null);return}try{chrome.runtime.sendMessage({type:"SOCIAL_MEDIA_HEARTBEAT"},()=>{chrome.runtime.lastError})}catch{E&&(clearInterval(E),E=null)}}function N(){try{return!!chrome.runtime?.id}catch{return!1}}async function K(){if(N())try{let e=await x({type:"GET_GLOBAL_SESSION"});if(e&&"phase"in e){let t=e.phase,o=await x({type:"GET_EFFECTIVE_BLUR_THRESHOLD",phase:t});if(o&&"threshold"in o){let n=o.threshold;(n!==U||t!==ce)&&(a.debug(` Blur threshold updated - phase: ${t}, threshold: ${n}`),U=n,ce=t)}}}catch{}}function ae(e){return(e.apiScore??e.heuristicScore)>=(L?ye:U)}function Fe(){E||(j(),K(),E=setInterval(()=>{j(),K()},Ye),document.addEventListener("visibilitychange",()=>{document.visibilityState==="visible"&&(j(),K())}),a.debug(" Twitter heartbeat tracking started"))}function Qe(){C||(C=setInterval(()=>{if(!N()){C&&(clearInterval(C),C=null);return}if(R())return;let e=Date.now()-he,t=document.querySelectorAll('[data-testid="tweet"]').length>0,o=document.querySelectorAll('[data-testid="cellInnerDiv"]:not(:has(.tolerance-score-badge)) [data-testid="tweet"]').length>0;e>15e3&&t&&o&&!I&&(a.debug(" Recovery check - detected unbadged tweets, reprocessing"),I=!1,q=!1,P())},ze),a.debug(" Recovery check started"))}var le=!1,be=3e3,U=55,ce="normal",L=!1,ye=21,O=new WeakMap;function we(){if(le)return;le=!0;let e=document.createElement("style");e.id="tolerance-twitter-styles",e.textContent=`
    /* Blur/fade effect on tweets during loading */
    [data-testid="primaryColumn"].tolerance-loading [data-testid="cellInnerDiv"] {
      filter: blur(2px);
      opacity: 0.5;
      transition: filter 0.2s ease, opacity 0.2s ease;
      pointer-events: none;
    }

    [data-testid="cellInnerDiv"] {
      transition: filter 0.2s ease, opacity 0.2s ease;
    }

    /* Loading spinner overlay */
    .tolerance-loader {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      z-index: 9999;
      display: none;
      flex-direction: column;
      align-items: center;
      gap: 12px;
      background: rgba(30, 30, 30, 0.9);
      padding: 20px 28px;
      border-radius: 12px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
    }

    .tolerance-loader.visible {
      display: flex;
    }

    .tolerance-loader-spinner {
      width: 32px;
      height: 32px;
      border: 3px solid rgba(29, 155, 240, 0.3);
      border-top-color: #1d9bf0;
      border-radius: 50%;
      animation: tolerance-spin 0.8s linear infinite;
    }

    .tolerance-loader-text {
      color: #e0e0e0;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 14px;
      font-weight: 500;
    }

    @keyframes tolerance-spin {
      to { transform: rotate(360deg); }
    }

    /* Score badges */
    .tolerance-score-badge {
      position: absolute !important;
      top: 28px !important;
      right: 8px !important;
      padding: 2px 8px !important;
      border-radius: 12px !important;
      font-size: 11px !important;
      font-weight: 600 !important;
      font-family: -apple-system, BlinkMacSystemFont, sans-serif !important;
      color: white !important;
      opacity: 0.85 !important;
      z-index: 9999 !important;
      pointer-events: auto !important;
      cursor: help !important;
      box-shadow: 0 1px 3px rgba(0,0,0,0.3) !important;
      display: block !important;
    }
    .tolerance-score-badge.high { background: #e74c3c !important; }
    .tolerance-score-badge.medium { background: #f39c12 !important; }
    .tolerance-score-badge.low { background: #27ae60 !important; }
    .tolerance-score-badge.pending { background: #95a5a6 !important; }

    /* Ensure badge is not blurred */
    .tolerance-blurred .tolerance-score-badge,
    .tolerance-pending .tolerance-score-badge {
      filter: none !important;
      pointer-events: auto !important;
    }

    /* Badge tooltip */
    .tolerance-score-badge .tolerance-tooltip {
      visibility: hidden;
      opacity: 0;
      position: absolute;
      bottom: 100%;
      right: 0;
      margin-bottom: 8px;
      padding: 8px 12px;
      background: rgba(20, 20, 20, 0.95);
      color: #e0e0e0;
      border-radius: 8px;
      font-size: 12px;
      font-weight: 400;
      white-space: nowrap;
      box-shadow: 0 2px 8px rgba(0,0,0,0.4);
      transition: opacity 0.15s ease, visibility 0.15s ease;
      z-index: 10000;
      pointer-events: none;
    }
    .tolerance-score-badge:hover .tolerance-tooltip {
      visibility: visible;
      opacity: 1;
    }
    .tolerance-tooltip-reason {
      margin-bottom: 4px;
      font-style: italic;
      max-width: 250px;
      white-space: normal;
    }
    .tolerance-tooltip-positions {
      font-size: 11px;
      color: #aaa;
    }
    .tolerance-tooltip-positions.moved-up { color: #7dcea0; }
    .tolerance-tooltip-positions.moved-down { color: #e67e73; }

    /* Blur effect (pending and high-engagement) */
    .tolerance-blurred,
    .tolerance-pending {
      filter: blur(var(--tolerance-blur, 8px)) !important;
      transition: filter 0.3s ease !important;
    }

    /* Revealed state (set by JS after hover delay) */
    .tolerance-blurred.tolerance-revealed,
    .tolerance-pending.tolerance-revealed {
      filter: blur(0px) !important;
    }

    .tolerance-blur-overlay {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba(0, 0, 0, 0.1);
      z-index: 100;
      pointer-events: auto;
      cursor: not-allowed;
      opacity: 1;
      transition: opacity 0.3s ease;
    }
    .tolerance-revealed .tolerance-blur-overlay {
      opacity: 0;
      pointer-events: none;
    }
    .tolerance-blur-label {
      background: rgba(231, 76, 60, 0.9);
      color: white;
      padding: 6px 12px;
      border-radius: 16px;
      font-size: 12px;
      font-weight: 600;
      font-family: -apple-system, BlinkMacSystemFont, sans-serif;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    }
    .tolerance-pending .tolerance-blur-label {
      background: rgba(149, 165, 166, 0.9);
    }
  `,document.head.appendChild(e)}function Z(e){e.dataset.hoverSetup||(e.dataset.hoverSetup="true",e.addEventListener("mouseenter",()=>{let t=O.get(e);t&&clearTimeout(t);let o=setTimeout(()=>{e.classList.add("tolerance-revealed")},be);O.set(e,o)}),e.addEventListener("mouseleave",()=>{let t=O.get(e);t&&(clearTimeout(t),O.delete(e)),e.classList.remove("tolerance-revealed")}))}function We(){let e=document.querySelector(".tolerance-loader");return e||(e=document.createElement("div"),e.className="tolerance-loader",e.innerHTML=`
    <div class="tolerance-loader-spinner"></div>
    <div class="tolerance-loader-text">Loading tweets...</div>
  `,document.body.appendChild(e),e)}function Ve(e){we();let t=document.querySelector('[data-testid="primaryColumn"]');t&&t.classList.add("tolerance-loading");let o=We();if(e){let n=o.querySelector(".tolerance-loader-text");n&&(n.textContent=e)}o.classList.add("visible")}function Ge(){let e=document.querySelector('[data-testid="primaryColumn"]');e&&e.classList.remove("tolerance-loading");let t=document.querySelector(".tolerance-loader");t&&t.classList.remove("visible")}function de(e,t){if(!e.element){a.debug(` Badge injection failed - no element for tweet ${e.id}`);return}let o=e.element.closest('[data-testid="cellInnerDiv"]');if(!o){a.debug(` Badge injection failed - no cellInnerDiv for tweet ${e.id}`);return}if(o.querySelector(".tolerance-score-badge")){a.debug(` Badge already exists for tweet ${e.id}`);return}getComputedStyle(o).position==="static"&&(o.style.position="relative");let n=document.createElement("div");n.className=`tolerance-score-badge ${t.bucket}`,n.textContent=String(Math.round(t.score));let i=document.createElement("div");if(i.className="tolerance-tooltip",t.reason){let d=document.createElement("div");d.className="tolerance-tooltip-reason",d.textContent=`"${t.reason}"`,i.appendChild(d)}let r=document.createElement("div"),m=t.originalPosition-t.newPosition;m>0?(r.className="tolerance-tooltip-positions moved-up",r.textContent=`Position: ${t.originalPosition+1} \u2192 ${t.newPosition+1} (\u2191${m})`):m<0?(r.className="tolerance-tooltip-positions moved-down",r.textContent=`Position: ${t.originalPosition+1} \u2192 ${t.newPosition+1} (\u2193${Math.abs(m)})`):(r.className="tolerance-tooltip-positions",r.textContent=`Position: ${t.newPosition+1} (unchanged)`),i.appendChild(r);let l=document.createElement("div");l.className="tolerance-tooltip-positions",l.style.marginTop="4px";let u=[];t.mediaType&&u.push(`type:${t.mediaType}`),t.hasImage&&u.push("\u{1F4F7}"),t.hasQuote&&u.push("\u{1F4AC}"),u.length>0&&(l.textContent=u.join(" "),i.appendChild(l)),n.appendChild(i),o.appendChild(n),a.debug(` Badge injected for tweet ${e.id}, score=${t.score}, bucket=${t.bucket}`)}function je(e,t=8){if(!e.element)return;let o=e.element.closest('[data-testid="cellInnerDiv"]');if(o&&!(o.classList.contains("tolerance-blurred")||o.classList.contains("tolerance-pending"))&&(o.style.setProperty("--tolerance-blur",`${t}px`),o.classList.add("tolerance-pending"),Z(o),getComputedStyle(o).position==="static"&&(o.style.position="relative"),!o.querySelector(".tolerance-blur-overlay"))){let n=document.createElement("div");n.className="tolerance-blur-overlay",n.addEventListener("click",r=>{r.preventDefault(),r.stopPropagation()});let i=document.createElement("div");i.className="tolerance-blur-label",i.textContent="Scoring...",n.appendChild(i),o.appendChild(n)}}function Ke(e){if(!e.element)return;let t=e.element.closest('[data-testid="cellInnerDiv"]');if(!t)return;t.classList.remove("tolerance-pending"),t.classList.remove("tolerance-revealed"),t.style.removeProperty("--tolerance-blur");let o=t.querySelector(".tolerance-blur-overlay");o&&o.remove()}function ue(e,t,o,n=8){if(!e.element)return;let i=e.element.closest('[data-testid="cellInnerDiv"]');if(!i||(i.classList.remove("tolerance-pending"),i.classList.contains("tolerance-blurred")))return;i.style.setProperty("--tolerance-blur",`${n}px`),i.classList.add("tolerance-blurred"),Z(i),getComputedStyle(i).position==="static"&&(i.style.position="relative");let r=i.querySelector(".tolerance-blur-overlay");r&&r.remove();let m=document.createElement("div");m.className="tolerance-blur-overlay",m.addEventListener("click",u=>{u.preventDefault(),u.stopPropagation()});let l=document.createElement("div");l.className="tolerance-blur-label",l.textContent=o?`High engagement (${Math.round(t)}): ${o}`:`High engagement content (${Math.round(t)})`,l.style.maxWidth="80%",l.style.textAlign="center",m.appendChild(l),i.appendChild(m),a.debug(` Blurred high-engagement tweet ${e.id}, score=${t}`)}function me(e){return new Promise(t=>setTimeout(t,e))}async function pe(){if(X||G||R())return;G=!0,a.debug(" Starting tweet preload...");let e=10,t=600,o=250,n=0,i=0;Ve("Loading tweets...");try{for(;n<e;){let r=Q();if(a.debug(` Preload attempt ${n+1}, found ${r.length} tweets`),r.length>=Be){a.debug(` Preload complete - got ${r.length} tweets`);break}i+=t,window.scrollTo({top:i,behavior:"instant"}),await me(o),n++}window.scrollTo({top:0,behavior:"instant"}),await me(150)}finally{Ge(),X=!0,G=!1}}var v=null,w=null;function R(){return window.location.pathname.includes("/status/")}async function ge(){a.debug(" Twitter content script loaded on",window.location.href),await Je(),await Xe()}async function Je(){return new Promise(e=>{let t=()=>{document.querySelector('[data-testid="primaryColumn"]')?e():setTimeout(t,500)};t()})}async function Xe(){let e=await x({type:"GET_STATE"});if(!e||!("state"in e)){a.debug(" Failed to get state, extension inactive");return}if(v=e.state,w=e.settings,w.logLevel&&te(w.logLevel),w.platforms?.twitter===!1){a.debug(" Twitter platform disabled in settings, extension inactive");return}we(),a.debug(" Mode =",v.mode);let t=w?.twitter?.hoverRevealDelay??3;if(be=t*1e3,a.debug(` Hover reveal delay = ${t}s`),L=w.qualityMode??!1,a.debug(` Quality Mode = ${L}`),v.mode==="baseline"){let i=Ze();a.debug(` Baseline mode - ${i.toFixed(1)} days remaining`)}let o=await x({type:"ENSURE_SESSION"});a.debug(" Session result:",o),Fe(),Qe();let n=w?.twitter?.reorderEnabled??!1;v?.mode==="active"&&!R()&&n&&await pe(),await P(),V(fe),se(()=>{a.debug(" Navigation detected, resetting state"),J.clear(),_.clear(),X=!1,I=!1,q=!1,setTimeout(async()=>{a.debug(" Re-initializing after navigation, path:",window.location.pathname),V(fe);let i=w?.twitter?.reorderEnabled??!1;v?.mode==="active"&&!R()&&i&&await pe(),await P()},500)})}function Ze(){if(!v)return 7;let t=(Date.now()-v.baselineStartDate)/(1e3*60*60*24);return Math.max(0,v.baselineDurationDays-t)}async function fe(){a.debug(" New tweets detected"),await P()}async function P(){if(!R()){if(I){q=!0,a.debug(" Processing already in progress, queued for later");return}I=!0;try{let e=performance.now(),t=Q(),o=performance.now(),n=[],i=[];for(let s of t)if(!J.has(s.id))n.push(s);else{let c=s.element?.closest('[data-testid="cellInnerDiv"]');c&&!c.querySelector(".tolerance-score-badge")&&_.has(s.id)&&i.push(s)}if(i.length>0){a.debug(` Re-injecting ${i.length} badges for processed tweets`);for(let s of i){let c=_.get(s.id);if(c){let f=c.score.apiScore??c.score.heuristicScore;de(s,{score:f,bucket:c.score.bucket,reason:c.score.apiReason,originalPosition:c.originalPosition,newPosition:c.originalPosition,hasImage:!!s.imageUrl,hasQuote:s.isQuoteTweet,mediaType:s.mediaType});let y=w?.twitter;y?.blurHighEngagement&&!y?.reorderEnabled&&ae(c.score)&&ue(s,f,c.score.apiReason,y.blurIntensity)}}}if(n.length===0)return;a.debug(` Processing ${n.length} new tweets (scrape: ${(o-e).toFixed(0)}ms)`),he=Date.now();let r=w?.twitter;if(r?.blurHighEngagement&&!r?.reorderEnabled)for(let s of n)je(s,r.blurIntensity??8);for(let s of n){let c=s.quotedTweet?`quotedAuthor=${s.quotedTweet.author}, quotedText="${s.quotedTweet.text?.slice(0,30)}...", quotedImage=${!!s.quotedTweet.imageUrl}`:"no quote";a.debug(` Tweet ${s.id.slice(0,8)}... mediaType=${s.mediaType}, hasImage=${!!s.imageUrl}, isQuote=${s.isQuoteTweet}, ${c}, text="${s.text.slice(0,30)}..."`)}let m=n.map(re),l=performance.now(),u=await x({type:"SCORE_TWEETS",tweets:m}),d=performance.now();if(a.debug(` SCORE_TWEETS took ${(d-l).toFixed(0)}ms`),!u||!("scores"in u)){a.error(" Failed to get scores - tweets will be retried");return}for(let s of n)J.add(s.id);let g=new Map;for(let s of u.scores)g.set(s.postId,s);let b=new Map(n.map(s=>[s.id,s]));et(u.scores);let h,p=w?.twitter??{reorderEnabled:!1,blurHighEngagement:!0,blurIntensity:8};if(v?.mode==="baseline")h=$(n,g);else if(p.reorderEnabled){let s=await x({type:"GET_SCHEDULER_ORDER",postIds:n.map(c=>c.id),scores:u.scores});if(s&&"orderedIds"in s){h=ie(n,g,s.orderedIds);let c=h.filter(f=>f.wasReordered).length;c>0&&a.debug(` Reordered ${c} tweets`)}else h=$(n,g)}else a.debug(" Twitter reordering disabled, using blur instead"),h=$(n,g);if(p.blurHighEngagement&&!p.reorderEnabled)for(let s of n){let c=g.get(s.id);if(c)if(ae(c)){let f=c.apiScore??c.heuristicScore;ue(s,f,c.apiReason,p.blurIntensity)}else Ke(s)}for(let s of h){let c=b.get(s.postId),f=g.get(s.postId);if(c&&f){_.set(c.id,{score:f,originalPosition:s.originalPosition});let y=f.apiScore??f.heuristicScore;de(c,{score:y,bucket:f.bucket,reason:f.apiReason,originalPosition:s.originalPosition,newPosition:s.position,hasImage:!!c.imageUrl,hasQuote:c.isQuoteTweet,mediaType:c.mediaType})}}await x({type:"LOG_IMPRESSIONS",impressions:h})}catch(e){a.error(" Error processing tweets:",e)}finally{I=!1,q&&(q=!1,a.debug(" Processing queued tweets"),setTimeout(()=>P(),50))}}}function et(e){let t={high:0,medium:0,low:0};for(let o of e)t[o.bucket]++;a.debug(`Scores - High: ${t.high}, Medium: ${t.medium}, Low: ${t.low}`)}async function x(e){return N()?new Promise(t=>{try{chrome.runtime.sendMessage(e,o=>{chrome.runtime.lastError?((chrome.runtime.lastError.message||"").includes("Extension context invalidated")?a.warn(" Extension was reloaded - please refresh the page"):a.error(" Message error:",chrome.runtime.lastError),t(null)):t(o)})}catch(o){a.warn(" Extension context lost:",o),t(null)}}):(a.warn(" Extension context invalidated - please refresh the page"),null)}function tt(){let e=w?.twitter;if(!e?.blurHighEngagement||e?.reorderEnabled)return;a.debug(` Refreshing blur state, qualityMode=${L}`);let t=document.querySelectorAll('[data-testid="cellInnerDiv"]');for(let o of t){let n=o.querySelector(".tolerance-score-badge");if(!n)continue;let i=n.textContent?.trim(),r=parseInt(i||"0",10);if(isNaN(r))continue;let l=r>=(L?ye:U),u=o.classList.contains("tolerance-blurred");if(l&&!u){let d=o;if(d.style.setProperty("--tolerance-blur",`${e.blurIntensity??8}px`),d.classList.add("tolerance-blurred"),getComputedStyle(d).position==="static"&&(d.style.position="relative"),!d.querySelector(".tolerance-blur-overlay")){let g=document.createElement("div");g.className="tolerance-blur-overlay",g.addEventListener("click",h=>{h.preventDefault(),h.stopPropagation()});let b=document.createElement("div");b.className="tolerance-blur-label",b.textContent=`High engagement content (${r})`,b.style.maxWidth="80%",b.style.textAlign="center",g.appendChild(b),d.appendChild(g)}Z(d)}else if(!l&&u){o.classList.remove("tolerance-blurred"),o.classList.remove("tolerance-revealed"),o.style.removeProperty("--tolerance-blur");let d=o.querySelector(".tolerance-blur-overlay");d&&d.remove()}}}chrome.runtime.onMessage.addListener((e,t,o)=>(e.type==="QUALITY_MODE_CHANGED"&&(L=e.enabled,a.debug(` Quality mode ${L?"enabled":"disabled"}`),tt(),o({success:!0})),!0));document.readyState==="loading"?document.addEventListener("DOMContentLoaded",ge):ge();})();
