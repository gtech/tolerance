"use strict";(()=>{var g={off:0,error:1,warn:2,info:3,debug:4},w="error";function B(e){w=e}var r={debug:(...e)=>{g[w]>=g.debug&&console.log("Tolerance:",...e)},info:(...e)=>{g[w]>=g.info&&console.log("Tolerance:",...e)},warn:(...e)=>{g[w]>=g.warn&&console.warn("Tolerance:",...e)},error:(...e)=>{g[w]>=g.error&&console.error("Tolerance:",...e)}};var R={economic:["collapse","crash","recession","depression","hyperinflation","bubble burst","bubble bursting","can't afford","priced out","housing crisis","wage stagnation","layoffs everywhere","job market dead","economy tanking","market crash","financial ruin","going bankrupt","poverty"],political:["democracy dying","democracy dead","end times","country is doomed","no hope left","nothing will change","both sides same","rigged system","point of no return","too far gone","beyond saving","irreversible damage","no way back","failed state"],existential:["humanity doomed","no future","too late","giving up","why bother","what's the point","learned helplessness","nothing matters","inevitable decline","all downhill","beyond repair","hopeless","despair","nihilism"]},V={hidden_forces:["they don't want you to know","wake up","open your eyes","hidden agenda","puppet masters","pulling strings","controlled opposition","deep state","powers that be","shadow government","secret cabal","ruling class"],coordinated:["psyop","propaganda","manufactured","astroturfing","narrative control","media manipulation","cover up","suppressed","silenced","censored truth","coordinated attack","disinformation campaign","controlled narrative"],revelation:["exposed","leaked","whistleblower","secret documents","finally revealed","proof they","caught red handed","smoking gun","hidden truth","real story"]},H={alienation:["forever alone","no one understands","outsider","don't belong","black sheep","outcast","invisible","nobody cares","all alone","isolated","disconnected","alienated"],grievance:["always blamed","under attack","discriminated against","demonized","scapegoat","targeted","hated for being","persecuted","vilified","marginalized"],hopelessness:["will never","impossible to","gave up on","not for people like me","rigged against","can't win","system designed to fail","born to lose","no chance","destined to fail"]};var Le=[{id:"doom",name:"Doom / Hopelessness",description:"Content promoting despair, learned helplessness, economic collapse fears, or nihilism. Often frames situations as irreversible and action as pointless.",keywords:[...R.economic,...R.political,...R.existential],isSystemTheme:!0,active:!0},{id:"conspiracy",name:"Conspiracy / Manipulation",description:`Content suggesting hidden forces control events, "they don't want you to know" framing, or coordinated cover-ups without evidence.`,keywords:[...V.hidden_forces,...V.coordinated,...V.revelation],isSystemTheme:!0,active:!0},{id:"identity",name:"Identity / Isolation",description:'Content promoting alienation, identity-based grievance, or "forever alone" narratives. Often frames social connection as impossible.',keywords:[...H.alienation,...H.grievance,...H.hopelessness],isSystemTheme:!0,active:!0}];function z(){let e=[],t=document.querySelectorAll("ytd-rich-item-renderer"),o=document.querySelectorAll("ytd-compact-video-renderer"),n=document.querySelectorAll("yt-lockup-view-model.yt-lockup-view-model--wrapper"),i=document.querySelectorAll("ytd-video-renderer");r.debug(` Found ${t.length} home, ${o.length} sidebar, ${n.length} lockup, ${i.length} list videos`);for(let c of[...t,...o,...n,...i]){let u=se(c);u&&e.push(u)}return r.debug(` Scraped ${e.length} valid videos`),e}function se(e){try{let o=e.querySelector('a[href*="/watch?v="], a[href*="/shorts/"], a.yt-lockup-view-model__content-image')?.getAttribute("href")||"",n=null,i=!1,c=o.match(/[?&]v=([a-zA-Z0-9_-]+)/),u=o.match(/\/shorts\/([a-zA-Z0-9_-]+)/);if(c?n=c[1]:u&&(n=u[1],i=!0),!n){let $=e.querySelector("a")?.getAttribute("href")||"";return $.includes("googleadservices")||r.debug(" No video ID found, href:",o,"any link href:",$),null}let d=e.querySelector(".yt-lockup-metadata-view-model__title, a.yt-lockup-metadata-view-model__title, h3[title], #video-title, #video-title-link, .title"),s=d?.textContent?.trim()||"";if(!s&&d&&(s=d.getAttribute("title")||""),s||(s=e.querySelector("h3[title]")?.getAttribute("title")||""),!s)return r.debug(" No title found for video",n),null;let p=e.querySelector('.yt-content-metadata-view-model__metadata-row a[href^="/@"], a[href^="/@"], #channel-name, .ytd-channel-name, [id*="channel"]')?.textContent?.trim()||"",l=e.querySelector(".yt-content-metadata-view-model, .yt-content-metadata-view-model__metadata-row, #metadata-line, .ytd-video-meta-block, #metadata")?.textContent||"",m=le(l),k=ce(l),ne=e.querySelector(".yt-badge-shape__text, badge-shape .yt-badge-shape__text, span.ytd-thumbnail-overlay-time-status-renderer, .badge-shape-wiz__text")?.textContent?.trim(),re=l.toLowerCase().includes("watching")||e.querySelector('[overlay-style="LIVE"]')!==null,ie=e.querySelector(".ytThumbnailViewModelImage img, img.ytCoreImageHost, #thumbnail img, img.yt-core-image")?.src;return{id:n,platform:"youtube",title:s,channel:p,viewCount:m,uploadDate:k,duration:ne,thumbnailUrl:ie,isShort:i,isLive:re,element:e}}catch(t){return console.error("Tolerance: Failed to parse YouTube video element:",t),null}}function le(e){let t=e.match(/([\d,.]+)\s*([KMB]?)\s*views?/i);if(!t)return 0;let o=t[1].replace(/,/g,""),n=parseFloat(o);switch(t[2].toUpperCase()){case"K":return Math.round(n*1e3);case"M":return Math.round(n*1e6);case"B":return Math.round(n*1e9);default:return Math.round(n)}}function ce(e){let t=e.match(/(\d+\s+(?:second|minute|hour|day|week|month|year)s?\s+ago)/i);if(t)return t[1];let o=e.match(/Streamed\s+(\d+\s+\w+\s+ago)/i);if(o)return o[1]}function F(e){let{element:t,...o}=e;return o}var L=null,O=null,de=500;function D(e){L&&L.disconnect(),r.debug(" Setting up YouTube content observer"),L=new MutationObserver(t=>{let o=!1,n="ytd-rich-item-renderer, ytd-compact-video-renderer, ytd-video-renderer, yt-lockup-view-model";for(let i of t){for(let c of i.addedNodes)if(c instanceof HTMLElement&&(c.matches?.(n)||c.querySelector?.(n))){o=!0;break}if(o)break}o&&(O&&clearTimeout(O),O=setTimeout(()=>{e()},de))}),L.observe(document.body,{childList:!0,subtree:!0})}function U(e){let t=history.pushState,o=history.replaceState;history.pushState=function(...n){t.apply(this,n),e()},history.replaceState=function(...n){o.apply(this,n),e()},window.addEventListener("popstate",e),window.addEventListener("yt-navigate-finish",e)}var Y=new Set,_=new Map,v=!1,E=!1,ue=1e4,S=null,ee=Date.now(),me=3e4,b=null;function I(){try{return!!chrome.runtime?.id}catch{return!1}}function A(){if(!I()){b&&(clearInterval(b),b=null);return}try{chrome.runtime.sendMessage({type:"SOCIAL_MEDIA_HEARTBEAT"},()=>{chrome.runtime.lastError})}catch{b&&(clearInterval(b),b=null)}}function pe(){b||(A(),P(),b=setInterval(()=>{A(),P()},me),document.addEventListener("visibilitychange",()=>{document.visibilityState==="visible"&&(A(),P())}),r.debug(" YouTube heartbeat tracking started"))}function he(){S||(S=setInterval(()=>{if(!I()){S&&(clearInterval(S),S=null);return}if(we())return;let e=Date.now()-ee,t=document.querySelectorAll("ytd-rich-item-renderer, ytd-compact-video-renderer").length>0,o=document.querySelectorAll("ytd-rich-item-renderer:not(:has(.tolerance-score-badge)), ytd-compact-video-renderer:not(:has(.tolerance-score-badge))").length>0;e>15e3&&t&&o&&!v&&(r.debug(" Recovery check - detected unbadged videos, reprocessing"),v=!1,E=!1,T())},ue),r.debug(" Recovery check started"))}var G=!1,te=3e3,C=55,W="normal",f=!1,oe=21;async function P(){if(I())try{let e=await x({type:"GET_GLOBAL_SESSION"});if(e&&"phase"in e){let t=e.phase,o=await x({type:"GET_EFFECTIVE_BLUR_THRESHOLD",phase:t});if(o&&"threshold"in o){let n=o.threshold;(n!==C||t!==W)&&(r.debug(` YouTube blur threshold updated - phase: ${t}, threshold: ${n}`),C=n,W=t)}}}catch{}}function K(e){return(e.apiScore??e.heuristicScore)>=(f?oe:C)}var M=new WeakMap;function ge(){if(G)return;G=!0;let e=document.createElement("style");e.id="tolerance-youtube-styles",e.textContent=`
    /* Score badges */
    .tolerance-score-badge {
      position: absolute !important;
      bottom: -49px !important;
      right: 8px !important;
      padding: 2px 8px !important;
      border-radius: 12px !important;
      font-size: 11px !important;
      font-weight: 600 !important;
      font-family: -apple-system, BlinkMacSystemFont, sans-serif !important;
      color: white !important;
      opacity: 0.9 !important;
      z-index: 9999 !important;
      pointer-events: auto !important;
      cursor: help !important;
      box-shadow: 0 1px 3px rgba(0,0,0,0.3) !important;
      display: block !important;
    }
    .tolerance-score-badge.high { background: #e74c3c !important; }
    .tolerance-score-badge.medium { background: #f39c12 !important; }
    .tolerance-score-badge.low { background: #27ae60 !important; }
    .tolerance-score-badge.pending { background: #95a5a6 !important; }

    /* Ensure badge is not blurred on blurred videos */
    .tolerance-blurred .tolerance-score-badge,
    .tolerance-pending .tolerance-score-badge {
      filter: none !important;
      pointer-events: auto !important;
    }

    /* Sidebar video badge positioning (far right of card, vertically centered) */
    .tolerance-sidebar-video {
      position: relative !important;
    }
    .tolerance-sidebar-video > .tolerance-score-badge {
      position: absolute !important;
      top: 50% !important;
      bottom: auto !important;
      right: 8px !important;
      left: auto !important;
      transform: translateY(-50%) !important;
      font-size: 12px !important;
      padding: 4px 8px !important;
      z-index: 1000 !important;
    }

    /* Badge tooltip */
    .tolerance-score-badge .tolerance-tooltip {
      visibility: hidden;
      opacity: 0;
      position: absolute;
      bottom: 100%;
      right: 0;
      margin-bottom: 8px;
      padding: 8px 12px;
      background: rgba(20, 20, 20, 0.95);
      color: #e0e0e0;
      border-radius: 8px;
      font-size: 12px;
      font-weight: 400;
      white-space: nowrap;
      box-shadow: 0 2px 8px rgba(0,0,0,0.4);
      transition: opacity 0.15s ease, visibility 0.15s ease;
      z-index: 10000;
      pointer-events: none;
    }
    .tolerance-score-badge:hover .tolerance-tooltip {
      visibility: visible;
      opacity: 1;
    }
    .tolerance-tooltip-reason {
      margin-bottom: 4px;
      font-style: italic;
      max-width: 250px;
      white-space: normal;
    }
    .tolerance-tooltip-meta {
      font-size: 11px;
      color: #aaa;
    }

    /* Blur effect - covers entire video card (title, description, thumbnail) */
    .tolerance-blurred,
    .tolerance-pending {
      filter: blur(var(--tolerance-blur, 8px)) !important;
      transition: filter 0.3s ease !important;
    }

    /* Revealed state (set by JS after hover delay) */
    .tolerance-blurred.tolerance-revealed,
    .tolerance-pending.tolerance-revealed {
      filter: blur(0px) !important;
    }

    .tolerance-blur-overlay {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba(0, 0, 0, 0.1);
      z-index: 100;
      pointer-events: auto;
      cursor: not-allowed;
      opacity: 1;
      transition: opacity 0.3s ease;
    }
    .tolerance-revealed .tolerance-blur-overlay {
      opacity: 0;
      pointer-events: none;
    }
    .tolerance-blur-label {
      background: rgba(231, 76, 60, 0.9);
      color: white;
      padding: 6px 12px;
      border-radius: 16px;
      font-size: 12px;
      font-weight: 600;
      font-family: -apple-system, BlinkMacSystemFont, sans-serif;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    }
    .tolerance-pending .tolerance-blur-label {
      background: rgba(149, 165, 166, 0.9);
    }
  `,document.head.appendChild(e)}function be(){sessionStorage.getItem("tolerance-preview-tip")||(r.info(`Tip: For best results, disable YouTube video previews:
Click your profile icon \u2192 Settings \u2192 Playback and performance \u2192 uncheck "Video previews"`),sessionStorage.setItem("tolerance-preview-tip","true"))}function N(e){e.dataset.hoverSetup||(e.dataset.hoverSetup="true",e.addEventListener("mouseenter",()=>{let t=M.get(e);t&&clearTimeout(t);let o=setTimeout(()=>{e.classList.add("tolerance-revealed")},te);M.set(e,o)}),e.addEventListener("mouseleave",()=>{let t=M.get(e);t&&(clearTimeout(t),M.delete(e)),e.classList.remove("tolerance-revealed")}))}function j(e,t){if(!e.element||e.element.querySelector(".tolerance-score-badge"))return;let o=e.element.matches("yt-lockup-view-model, ytd-compact-video-renderer")||e.element.closest("ytd-watch-next-secondary-results-renderer")!==null,n;if(o)n=e.element,e.element.classList.add("tolerance-sidebar-video");else{let s=e.element.querySelector("a.yt-lockup-view-model__content-image, yt-thumbnail-view-model, .ytThumbnailViewModelImage, #thumbnail, ytd-thumbnail");if(!s){r.debug(` No thumbnail found for video ${e.id}`);return}n=s}getComputedStyle(n).position==="static"&&(n.style.position="relative");let i=document.createElement("div");i.className=`tolerance-score-badge ${t.bucket}`,i.textContent=String(Math.round(t.score));let c=document.createElement("div");if(c.className="tolerance-tooltip",t.reason){let s=document.createElement("div");s.className="tolerance-tooltip-reason",s.textContent=`"${t.reason}"`,c.appendChild(s)}let u=document.createElement("div");u.className="tolerance-tooltip-meta";let d=[];t.channel&&d.push(t.channel),t.viewCount&&d.push(`${fe(t.viewCount)} views`),d.length>0&&(u.textContent=d.join(" \u2022 "),c.appendChild(u)),i.appendChild(c),n.appendChild(i),r.debug(` Badge injected for video ${e.id}, score=${t.score}, bucket=${t.bucket}${o?" (sidebar)":""}`)}function fe(e){return e>=1e9?(e/1e9).toFixed(1)+"B":e>=1e6?(e/1e6).toFixed(1)+"M":e>=1e3?(e/1e3).toFixed(1)+"K":e.toString()}function ye(e,t=8){if(!e.element||e.element.classList.contains("tolerance-blurred")||e.element.classList.contains("tolerance-pending"))return;e.element.style.setProperty("--tolerance-blur",`${t}px`),e.element.classList.add("tolerance-pending"),N(e.element);let o=e.element.querySelector("a.yt-lockup-view-model__content-image, yt-thumbnail-view-model, .ytThumbnailViewModelImage, #thumbnail, ytd-thumbnail");if(o&&(getComputedStyle(o).position==="static"&&(o.style.position="relative"),!o.querySelector(".tolerance-blur-overlay"))){let n=document.createElement("div");n.className="tolerance-blur-overlay",n.addEventListener("click",c=>{c.preventDefault(),c.stopPropagation()});let i=document.createElement("div");i.className="tolerance-blur-label",i.textContent="Scoring...",n.appendChild(i),o.appendChild(n)}}function ve(e){if(!e.element)return;e.element.classList.remove("tolerance-pending"),e.element.classList.remove("tolerance-revealed"),e.element.style.removeProperty("--tolerance-blur");let t=e.element.querySelector(".tolerance-blur-overlay");t&&t.remove()}function Q(e,t,o,n=8){if(!e.element||(e.element.classList.remove("tolerance-pending"),e.element.classList.contains("tolerance-blurred")))return;e.element.style.setProperty("--tolerance-blur",`${n}px`),e.element.classList.add("tolerance-blurred"),N(e.element);let i=e.element.querySelector("a.yt-lockup-view-model__content-image, yt-thumbnail-view-model, .ytThumbnailViewModelImage, #thumbnail, ytd-thumbnail");if(i){getComputedStyle(i).position==="static"&&(i.style.position="relative");let c=i.querySelector(".tolerance-blur-overlay");c&&c.remove();let u=document.createElement("div");u.className="tolerance-blur-overlay",u.addEventListener("click",s=>{s.preventDefault(),s.stopPropagation()});let d=document.createElement("div");d.className="tolerance-blur-label",d.textContent=o?`High engagement (${Math.round(t)}): ${o}`:`High engagement (${Math.round(t)})`,d.style.maxWidth="80%",d.style.textAlign="center",u.appendChild(d),i.appendChild(u)}r.debug(` Blurred high-engagement video ${e.id}, score=${t}`)}var Z=null,y=null;function we(){return window.location.pathname.startsWith("/watch")}function q(){return window.location.pathname.startsWith("/shorts")}async function J(){r.debug(" YouTube content script loaded on",window.location.href),await Se(),await Ee()}async function Se(){return new Promise(e=>{let t=()=>{document.querySelector("ytd-app")?e():setTimeout(t,500)};t()})}async function Ee(){let e=await x({type:"GET_STATE"});if(!e||!("state"in e)){r.debug(" Failed to get state, extension inactive");return}if(Z=e.state,y=e.settings,y.logLevel&&B(y.logLevel),y.platforms?.youtube===!1){r.debug(" YouTube platform disabled in settings, extension inactive");return}ge(),be(),r.debug(" Mode =",Z.mode);let t=y?.twitter?.hoverRevealDelay??3;te=t*1e3,r.debug(` Hover reveal delay = ${t}s`),f=y.qualityMode??!1,r.debug(` Quality Mode = ${f}`);let o=await x({type:"ENSURE_SESSION"});r.debug(" Session result:",o),pe(),he(),q()||await T(),D(X),U(()=>{r.debug(" Navigation detected, resetting state"),Y.clear(),_.clear(),v=!1,E=!1,setTimeout(async()=>{r.debug(" Re-initializing after navigation, path:",window.location.pathname),D(X),q()||await T()},500)})}async function X(){r.debug(" New videos detected"),await T()}async function T(){if(!q()){if(v){E=!0,r.debug(" Processing already in progress, queued for later");return}v=!0;try{let e=performance.now(),t=z(),o=performance.now(),n=[],i=[];for(let a of t)if(!Y.has(a.id))n.push(a);else{let l=a.element?.querySelector("#thumbnail, ytd-thumbnail");l&&!l.querySelector(".tolerance-score-badge")&&_.has(a.id)&&i.push(a)}if(i.length>0){r.debug(` Re-injecting ${i.length} badges for processed videos`);for(let a of i){let l=_.get(a.id);if(l){let m=l.score.apiScore??l.score.heuristicScore;j(a,{score:m,bucket:l.score.bucket,reason:l.score.apiReason,channel:a.channel,viewCount:a.viewCount}),K(l.score)&&Q(a,m,l.score.apiReason,8)}}}if(n.length===0)return;r.debug(` Processing ${n.length} new videos (scrape: ${(o-e).toFixed(0)}ms)`),ee=Date.now();for(let a of n)ye(a,8);let c=n.map(F),u=performance.now(),d=await x({type:"SCORE_VIDEOS",videos:c}),s=performance.now();if(r.debug(` SCORE_VIDEOS took ${(s-u).toFixed(0)}ms`),!d||!("scores"in d)){r.error(" Failed to get scores - videos will be retried");return}for(let a of n)Y.add(a.id);let h=new Map;for(let a of d.scores)h.set(a.postId,a);let p={high:0,medium:0,low:0};for(let a of d.scores)p[a.bucket]++;r.debug(` Scores - High: ${p.high}, Medium: ${p.medium}, Low: ${p.low}`);for(let a=0;a<n.length;a++){let l=n[a],m=h.get(l.id);if(m){_.set(l.id,{score:m,position:a});let k=m.apiScore??m.heuristicScore;j(l,{score:k,bucket:m.bucket,reason:m.apiReason,channel:l.channel,viewCount:l.viewCount}),K(m)?Q(l,k,m.apiReason,8):ve(l)}}}catch(e){r.error(" Error processing videos:",e)}finally{v=!1,E&&(E=!1,r.debug(" Processing queued videos"),setTimeout(()=>T(),50))}}}async function x(e){return I()?new Promise(t=>{try{chrome.runtime.sendMessage(e,o=>{chrome.runtime.lastError?((chrome.runtime.lastError.message||"").includes("Extension context invalidated")?r.warn(" Extension was reloaded - please refresh the page"):r.error(" Message error:",chrome.runtime.lastError),t(null)):t(o)})}catch(o){r.warn(" Extension context lost:",o),t(null)}}):(r.warn(" Extension context invalidated - please refresh the page"),null)}function Te(){r.debug(` Refreshing blur state, qualityMode=${f}`);let e=document.querySelectorAll("ytd-rich-item-renderer, ytd-compact-video-renderer, yt-lockup-view-model");for(let t of e){let o=t.querySelector(".tolerance-score-badge");if(!o)continue;let n=o.textContent?.trim(),i=parseInt(n||"0",10);if(isNaN(i))continue;let u=i>=(f?oe:C),d=t.classList.contains("tolerance-blurred");if(u&&!d){let s=t;s.style.setProperty("--tolerance-blur","8px"),s.classList.add("tolerance-blurred"),N(s);let h=s.querySelector("a.yt-lockup-view-model__content-image, yt-thumbnail-view-model, .ytThumbnailViewModelImage, #thumbnail, ytd-thumbnail");if(h&&(getComputedStyle(h).position==="static"&&(h.style.position="relative"),!h.querySelector(".tolerance-blur-overlay"))){let p=document.createElement("div");p.className="tolerance-blur-overlay",p.addEventListener("click",l=>{l.preventDefault(),l.stopPropagation()});let a=document.createElement("div");a.className="tolerance-blur-label",a.textContent=`High engagement content (${i})`,a.style.maxWidth="80%",a.style.textAlign="center",p.appendChild(a),h.appendChild(p)}}else if(!u&&d){t.classList.remove("tolerance-blurred"),t.classList.remove("tolerance-revealed"),t.style.removeProperty("--tolerance-blur");let s=t.querySelector(".tolerance-blur-overlay");s&&s.remove()}}}chrome.runtime.onMessage.addListener((e,t,o)=>(e.type==="QUALITY_MODE_CHANGED"&&(f=e.enabled,r.debug(` Quality mode ${f?"enabled":"disabled"}`),Te(),o({success:!0})),!0));document.readyState==="loading"?document.addEventListener("DOMContentLoaded",J):J();})();
